import socket,select
import logging
import struct

class parse_dhcp():
    version = 4
    type = 0

    def __init__(self, xid=None, elements=None):
        if xid != None:
            self.xid = xid
        else:
            self.xid = None
        if elements != None:
            self.elements = elements
        else:
            self.elements = []
        return

    def pack(self):
        packed = []
        packed.append(struct.pack("!B", self.version))
        packed.append(struct.pack("!B", self.type))
        packed.append(struct.pack("!H", 0)) # placeholder for length at index 2
        packed.append(struct.pack("!L", self.xid))
        packed.append(loxi.generic_util.pack_list(self.elements))
        length = sum([len(x) for x in packed])
        packed[2] = struct.pack("!H", length)
        return ''.join(packed)

    @staticmethod
    def unpack(reader):
        obj = hello()
        _version = reader.read("!B")[0]
        assert(_version == 4)
        _type = reader.read("!B")[0]
        assert(_type == 0)
        _length = reader.read("!H")[0]
        orig_reader = reader
        reader = orig_reader.slice(_length - (2 + 2))
        obj.xid = reader.read("!L")[0]
        obj.elements = loxi.generic_util.unpack_list(reader, common.hello_elem.unpack)
        return obj

def parse_mac(mac_str):
    return map(lambda val: int(val, 16), mac_str.split(":"))

def parse_ip(ip_str):
    array = map(lambda val: int(val), ip_str.split("."))
    val = 0
    for a in array:
        val <<= 8
        val += a
    return val

class dhcps():
    def __init__(self):
		self.sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		#server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
		self.sock.bind(('',67))
		self.sock.listen(5)
		self.sockets=[server]

    def run(self):
        while 1:
            sel_in, sel_out, sel_err = \
                    select.select(self.sockets(), [], self.sockets(), 1)
            for s in sel_in:
                if self.socket_handle(s) == -1:
                    continue
					
	def socket_handle(self,r):
		if r in self.sockets:
			client_sock, client_addr = r.accept()
			self.sockets.append(client_sock)
		else:
			data = r.recv(1024)
			if not data:
				self.sockets.remove(r)
				return -1

    def transact(self, msg, timeout=-1):
        if msg.xid == None:
            msg.xid = ofutils.gen_xid()
        self.logger.debug("Running transaction %d" % msg.xid)
        with self.xid_cv:
            if self.xid:
                self.logger.error("Can only run one transaction at a time")
                return (None, None)
            self.xid = msg.xid
            self.xid_response = None
            self.message_send(msg)
            self.logger.debug("Waiting for transaction %d" % msg.xid)
            ofutils.timed_wait(self.xid_cv, lambda: self.xid_response, timeout=timeout)
            if self.xid_response:
                (resp, pkt) = self.xid_response
                self.xid_response = None
            else:
                (resp, pkt) = (None, None)
        if resp is None:
            self.logger.warning("No response for xid " + str(self.xid))
        return (resp, pkt)