
class stack:
	stack_list = []
	def __init__(self):
		self.MAX = 5
		print stack_list
		
	def add(self,value):
		if len(stack_list) < self.MAX:	
			stack_list.append(value)
		else:
			push_list(stack_list, value)

	def push_list(self,stack_list,value): 
		for i in range(self.MAX-1):
			stack_list[-1-i] = stack_list[-2-i]
			
			
if __name__ == '__main__':
        a = stack()
        for i in range(100):
                a.add(i)
