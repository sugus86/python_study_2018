import struct

class DHCP():
    version = 4
    type = 0

    def __init__(self, xid=None, elements=None):
        if xid != None:
            self.xid = xid
        else:
            self.xid = None
        if elements != None:
            self.elements = elements
        else:
            self.elements = []
        return

    def pack(self):
        packed = []
        packed.append(struct.pack("!B", self.version))
        packed.append(struct.pack("!B", self.type))
        packed.append(struct.pack("!H", 0)) # placeholder for length at index 2
        packed.append(struct.pack("!L", self.xid))
        packed.append(loxi.generic_util.pack_list(self.elements))
        length = sum([len(x) for x in packed])
        packed[2] = struct.pack("!H", length)
        return ''.join(packed)

    @staticmethod
    def unpack(reader):
        obj = hello()
        _version = reader.read("!B")[0]
        assert(_version == 4)
        _type = reader.read("!B")[0]
        assert(_type == 0)
        _length = reader.read("!H")[0]
        orig_reader = reader
        reader = orig_reader.slice(_length - (2 + 2))
        obj.xid = reader.read("!L")[0]
        obj.elements = loxi.generic_util.unpack_list(reader, common.hello_elem.unpack)
        return obj

def parse_mac(mac_str):

    return map(lambda val: int(val, 16), mac_str.split(":"))

def parse_ip(ip_str):
    array = map(lambda val: int(val), ip_str.split("."))
    val = 0
    for a in array:
        val <<= 8
        val += a
    return val
