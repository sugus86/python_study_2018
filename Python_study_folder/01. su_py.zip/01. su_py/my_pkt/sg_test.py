import logging, time
import loxi
from testutils import *
from base_tests import SimpleProtocol as sp

import loxi.of13 as ofp

#####################**** User write the below things ****#######################
'''
class mytest(sp):
    def __init__(self):
	sdp.setUp(self)      
        self.run()

    def run(self):
        delete_all_flows(self.controller)
        parsed_pkt = simple_tcp_packet()
        pkt = str(parsed_pkt)
        match = self.test_match()

        request = ofp.message.flow_add(
            table_id=test_param_get("table", 0),
            cookie=42,
            instructions=[
                ofp.instruction.write_actions(
                    actions=[
                        ofp.action.output(
                            port=ofp.OFPP_CONTROLLER,
                            max_len=ofp.OFPCML_NO_BUFFER)])],
            buffer_id=ofp.OFP_NO_BUFFER,
            priority=0, match=match)

        logging.info("Inserting table-miss flow sending all packets to controller")
        self.controller.message_send(request)
        do_barrier(self.controller)

    def test_match(self):
    	in_phy_port = ofp.oxm.in_phy_port(20)	   
    	eth_dst = ofp.oxm.eth_dst([0x00,0x11,0x22,0x33,0x44,0x55])
    	eth_src = ofp.oxm.eth_src([0x00,0x11,0x22,0x33,0x44,0x88])
    	eth_type = ofp.oxm.eth_type(0x0800)	    
    	ipv4_dst = ofp.oxm.ipv4_dst(self.ip2int("10.0.0.4"))
    	ipv4_src=  ofp.oxm.ipv4_src(self.ip2int("10.0.0.2"))
    	ip_proto = ofp.oxm.ip_proto(6)
    	tcp_dst = ofp.oxm.tcp_dst(6666)
    	tcp_src = ofp.oxm.tcp_src(7777)
    	vlan_vid = ofp.oxm.vlan_vid(123)
    	match = ofp.match([in_phy_port, eth_type, eth_dst, eth_src, ipv4_dst, \
            ipv4_src, ip_proto, tcp_dst, tcp_src, vlan_vid])
    	return match
	
    def ip2int(self,ip):
        return int(ip.split('.')[0])*256*256*256 + int(ip.split('.')[1])*256*256 + \
       int(ip.split('.')[2])*256 + int(ip.split('.')[3])

mytest()
'''
###################################################################################################
'''
class mytest(sp):
    def __init__(self):
	sdp.setUp(self)      
        self.runtest()

    def runtest(self):
        match = ofp.match()
	table_id=test_param_get("table", 0)
	actions=[ofp.action.output(port=ofp.OFPP_CONTROLLER, max_len=ofp.OFPCML_NO_BUFFER)]
	instructions=[ofp.instruction.write_actions(actions)]
	buffer_id=ofp.OFP_NO_BUFFER

        request = ofp.message.flow_add(table_id=table_id, cookie=42, instructions=instructions,
            buffer_id=buffer_id, priority=0, match=match)
       
        self.controller.message_send(request)

mytest()
'''	
##################################################################################################

class mytest(sp):
    def __init__(self):
        sp.setUp(self)

    def add_flow_(self, match):
        self.logger = logging.getLogger("Add_Flow")
        self.match = match
        table_id=test_param_get("table", 0)
        actions=[ofp.action.output(port=ofp.OFPP_CONTROLLER, max_len=ofp.OFPCML_NO_BUFFER)]
        instructions=[ofp.instruction.write_actions(actions)]
        buffer_id=ofp.OFP_NO_BUFFER

        request = ofp.message.flow_add(table_id=table_id, cookie=42, instructions=instructions,
            buffer_id=buffer_id, priority=0, idle_timeout=30, hard_timeout=120, match=self.match)
       
        self.send_msg(request)
        self.logger.debug("Add flow to switch...")       

test = mytest()
#match = ofp.match([ofp.oxm.eth_type(0x0806),ofp.oxm.eth_src([0x00,0x02,0xa5,0x4e,0x92,0xce])])
#match = ofp.match([ofp.oxm.eth_type(0x0806),ofp.oxm.eth_dst([0x08,0x2e,0x5f,0x04,0xc8,0x78])])
#test.add_flow_(match=match)

match = ofp.match([ofp.oxm.eth_type(0x0800),ofp.oxm.eth_src([0x00,0x02,0xa5,0x4e,0x92,0xce])])
test.add_flow_(match=match)
