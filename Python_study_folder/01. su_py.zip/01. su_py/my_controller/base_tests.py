import logging
import os
import controller
import dataplane
import loxi.of13 as ofp

config = {"switch_ip":None, "controller_host":'172.31.168.132', "controller_port":6633}


class SimpleProtocol:
    def __init__(self):
        pass
    def setUp(self):
        self.controller = controller.Controller(
            switch=config["switch_ip"],
            host=config["controller_host"],
            port=config["controller_port"])
        self.controller.start()
        try:
            self.controller.connect(timeout=30)
            self.controller.keep_alive = True
            if not self.controller.active:
                raise Exception("Controller startup failed")
            if self.controller.switch_addr is None:
                raise Exception("Controller startup failed (no switch addr)")
            logging.info("Connected " + str(self.controller.switch_addr))
            request = ofp.message.features_request()
            reply, pkt = self.controller.transact(request)
            self.assertTrue(reply is not None,
                            "Did not complete features_request for handshake")
            if reply.version == 1:
                self.supported_actions = reply.actions
                logging.info("Supported actions: " + hex(self.supported_actions))
        except:
            self.controller.kill()
            del self.controller
            raise
			
    def assertTrue(self, cond, msg):
	if not cond:
	    logging.error("** FAILED ASSERTION: " + msg)

class SimpleDataPlane(SimpleProtocol):
    def __init__(self):
        self.setUp()
    def setUp(self):
        SimpleProtocol.setUp(self)
        self.dataplane = dataplane.DataPlane(config)
        self.dataplane.flush()
