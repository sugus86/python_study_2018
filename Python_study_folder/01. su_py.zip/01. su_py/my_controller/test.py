from controller import Controller as ctl
from dataplane import DataPlane as dpp
from base_tests import SimpleProtocol as spp

import time

'''
N = 1
config={"eth0":10}
while N:
    controller = ctl(host='172.31.168.132')
    controller.run()    
    dpp()
    N = N - 1
    time.sleep(1)
    print 'close'
'''

spp().setUp()