#-*- coding: utf8 -*-
def do_telnet(Host, username, password, finish, sw_port):
   import telnetlib   
   tn = telnetlib.Telnet(Host, port=23, timeout=10)  
   tn.set_debuglevel(2)     
   tn.read_until('user name:')  
   tn.write(username + '\n')   
   tn.read_until('password:')  
   tn.write(password + '\n')    
   tn.read_until('>')  
   tn.write("en" + '\n')
   tn.read_until('password:')  
   tn.write("lhadsl" + '\n')    
   tn.read_until(finish)
   command="show poe interface gi 0/" + str(sw_port)
   tn.write(command + '\n')
   temp1=tn.read_until(finish)
   tn.write(command + '\n')
   temp2=tn.read_until(finish)
   tn.write(command + '\n')
   temp3=tn.read_until(finish)
   tn.write(command + '\n')
   temp4=tn.read_until(finish)
   tn.write(command + '\n')
   temp5=tn.read_until(finish)
   poe_results=(temp1,temp2,temp3,temp4,temp5)
   command2="show interface gi 0/" + str(sw_port)
   tn.write(command2 + '\n')
   temp_int=tn.read_until(finish)
   tn.close()
   return (poe_results,temp_int)   
	   
if __name__=='__main__':   
   import xlrd
   data=xlrd.open_workbook("AP_sw_port_daily.xlsx")
   table=data.sheet_by_name(u'daily')
   finish='#' 
   for i in range(1,table.nrows):
       apname=table.cell(i,0).value
       sw_addr=str(table.cell(i,1).value)
       sw_port=int(table.cell(i,2).value)
       poe_results,int_results=do_telnet(sw_addr, "lhsqa", "lhsqa", finish, sw_port)
       print "#################################   " + apname +  "   ##############################"
       for t in poe_results:
			print t.split(':')[6].split()[0]+"/"+t.split(':')[8].split()[0]
       print int_results.split('\n')[1]
       print "##########################################################################################"	   