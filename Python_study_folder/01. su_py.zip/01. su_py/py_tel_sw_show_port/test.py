#!/usr/bin/env python
#-*- coding: utf8 -*-
f=open('D:\\so.txt','w+')
#f.write("hello world")
f.seek(0)
lines=f.readlines()
lines.append("\nlife is too short,weneed python")
f.seek(0)
f.writelines(lines)
f.close()
for line in open('D:\\so.txt','r+'):
   print line
