################################ Modified for try as a Controller from oftest ###################################
# Only for test. Isn't a completely controller.
# Modified by sugus.g.su

import socket
import time, sys, random
import struct
import select
import logging
from threading import Thread

import loxi.of13 as ofp

LISTEN_QUEUE_SIZE = 1

class Controller(Thread):
    def __init__(self, host='172.31.168.195', port=6633, max_pkts=1024):
        Thread.__init__(self)
        self.port = port
        self.host = host        
        self.active = True
        self.initial_hello = True
        self.sw_soc = None
        self.xid = None
        self.max_pkts = 1024

        self.logger = logging.getLogger("controller")
        logging.basicConfig(level=logging.DEBUG)

        self.logger.info("Create/listen at " + self.host + ":" + str(self.port)) 
        self.soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.soc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.soc.bind((self.host, self.port))
        self.soc.listen(LISTEN_QUEUE_SIZE)  
 
    def run(self):
        while self.active:
            try:                
                sel_in, sel_out, sel_err = select.select(self.sockets(), [], self.sockets(), 1)
            except:
                print sys.exc_info()
                self.logger.error("Select error, disconnecting")
                self.disconnect()

            for s in sel_err:
                self.logger.error("Got socket error on: " + str(s) + ", disconnecting")
                self.disconnect()

            for s in sel_in:
                if self._socket_ready_handle(s) == -1:
                    self.disconnect()

        self.dbg_state = "closing"
        self.logger.info("Exiting controller thread")
        self.shutdown()

    def sockets(self):
        socs = [self.soc, self.sw_soc]
        return [x for x in socs if x]        

    def disconnect(self):
        self.active = False        
        if self.soc:
            self.soc.close()
            self.soc = None
        if self.sw_soc:
            self.sw_soc.close()
            self.sw_soc = None
 
    def _socket_ready_handle(self, s):
        if not self.active:
            return -1
        if s and s == self.soc:
            if self.sw_soc:
                self.logger.warning("Ignoring incoming connection; already connected to switch")
                (sock, addr) = self.soc.accept()
                sock.close()
                return 0                
                
            try:                 
                (sock, addr) = self.soc.accept()
            except:
                self.logger.warning("Error on listen socket accept")
                return -1
            
            self.logger.info(self.host+":"+str(self.port)+": Incoming connection from "+str(addr))
            (self.sw_soc, self.sw_addr) = (sock, addr)
            self.sw_soc.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
            if self.initial_hello:
               self.message_send(ofp.message.hello())
               self.message_send(ofp.message.features_request())
               
            self.soc.close()
            self.soc = None
        elif s and s == self.sw_soc:
            for idx in range(3):
                try: pkt = self.sw_soc.recv(32768)
                except:
                    self.logger.warning("Error on switch read")
                    return -1      
                if not self.active:
                    return 0      
                if len(pkt) == 0:
                    self.logger.warning("Zero-length switch read, %d" % idx)
                else: break
            if len(pkt) == 0: # Still no packet
                self.logger.warning("Zero-length switch read; closing cxn")
                self.logger.info(str(self))
                return -1
            self._pkt_handle(pkt)

        else:
            self.logger.error("Unknown socket ready: " + str(s))
            return -1

    def message_send(self, msg):
        if not self.sw_soc:
            raise Exception("no socket")
        if msg.xid == None:
            msg.xid = self.gen_xid() 
        outpkt = msg.pack()
        self.logger.debug("Msg out: version %d class %s len %d xid %d",
                          msg.version, type(msg).__name__, len(outpkt), msg.xid)       
        if self.sw_soc.sendall(outpkt) is not None:
                raise AssertionError("failed to send message to switch")
        return 0    

    def shutdown(self):
        self.active = False
        try:
            self.sw_soc.shutdown(socket.SHUT_RDWR)
        except:
            self.logger.info("Ignoring switch soc shutdown error")
        self.sw_soc = None
        try:
            self.soc.shutdown(socket.SHUT_RDWR)
        except:
            self.logger.info("Ignoring soc shutdown error")
        self.soc = None        

    def gen_xid(self):
        return random.randrange(1,0xffffffff)

    def _pkt_handle(self, pkt):
        self.buffered_input = ""
        offset = 0
        while offset < len(pkt):
            if offset + 8 > len(pkt):
                break
            hdr_version, hdr_type, hdr_length, hdr_xid = ofp.message.parse_header(pkt[offset:])
            if (offset + hdr_length) > len(pkt):
                break
            rawmsg = pkt[offset : offset + hdr_length]
            offset += hdr_length
            msg = ofp.message.parse_message(rawmsg)
            if not msg:
                self.parse_errors += 1
                self.logger.warn("Could not parse message")
                continue
            self.logger.debug("Msg in: version %d class %s len %d xid %d",
                              hdr_version, type(msg).__name__, hdr_length, hdr_xid)
            if self.active:
                if hdr_type == ofp.OFPT_ECHO_REQUEST:
                    self.logger.debug("Responding to echo request")
                    rep = ofp.message.echo_reply()
                    rep.data = pkt[8:(offset + hdr_length)]
                    rep.xid = hdr_xid
                    self.message_send(rep)
                    continue

                if isinstance(msg, ofp.message.error_msg):
                    if msg.err_type in ofp.ofp_error_type_map:
                        type_str = ofp.ofp_error_type_map[msg.err_type]
                        if msg.err_type == ofp.OFPET_HELLO_FAILED:
                            code_map = ofp.ofp_hello_failed_code_map
                        elif msg.err_type == ofp.OFPET_BAD_REQUEST:
                            code_map = ofp.ofp_bad_request_code_map
                        elif msg.err_type == ofp.OFPET_BAD_ACTION:
                            code_map = ofp.ofp_bad_action_code_map
                        elif msg.err_type == ofp.OFPET_FLOW_MOD_FAILED:
                            code_map = ofp.ofp_flow_mod_failed_code_map
                        elif msg.err_type == ofp.OFPET_PORT_MOD_FAILED:
                            code_map = ofp.ofp_port_mod_failed_code_map
                        elif msg.err_type == ofp.OFPET_QUEUE_OP_FAILED:
                            code_map = ofp.ofp_queue_op_failed_code_map
                        else:
                            code_map = None
                        if code_map and msg.code in code_map:
                            code_str = code_map[msg.code]
                        else:
                            code_str = "unknown"
                    else:
                        type_str = "unknown"
                        code_str = "unknown"
                    self.logger.warn("Received error message: xid=%d type=%s (%d) code=%s (%d)",
                                     hdr_xid, type_str, msg.err_type, code_str, msg.code)
                    continue

                if hdr_type != ofp.OFPT_ECHO_REQUEST:
                    self.sg_handle(msg)
                    continue
                    
    ######################################### Below code defined by user #########################################
    def handle_packet_in(self, msg):
        msg = msg
        xid = msg.xid
        in_port = None
        out_port = ofp.OFPP_ALL
        actions = [ofp.action.output(port=out_port, max_len=ofp.OFPCML_NO_BUFFER)]
        data = None
        if msg.buffer_id == ofp.OFP_NO_BUFFER: data = msg.data
        out = ofp.message.packet_out(xid=xid, buffer_id=msg.buffer_id, in_port=in_port, actions=actions, data=data)
        self.logger.debug("Packet in handle...") 
        self.message_send(out)

    def add_flow_(self):
        match = ofp.match([ofp.oxm.eth_type(0x0806)])
        actions = [ofp.action.output(port=ofp.OFPP_CONTROLLER, max_len=ofp.OFPCML_NO_BUFFER)]        
        instructions = [ofp.instruction.write_actions(actions)]
        buffer_id = ofp.OFP_NO_BUFFER
        out = ofp.message.flow_add(cookie=42, instructions=instructions, buffer_id=buffer_id, priority=0, match=match)
        self.logger.debug("Add flow to switch...")
        self.message_send(out)

    def add_meter_(self):
        command = ofp.OFPMC_ADD
        flag = ofp.OFPMF_KBPS
        meter_id = 0x100
        band = [ofp.meter_band.drop(rate=100, burst_size=0)]
        out = ofp.message.meter_mod(command=command, flags=flag, meter_id=meter_id, meters=band)
        self.logger.debug("Add Meter to switch...")
        self.message_send(out)

    def sg_handle(self, msg):
        if msg.type==ofp.OFPT_FEATURES_REPLY:
            self.add_flow_()
            self.add_meter_()
        elif msg.type ==ofp.OFPT_PACKET_IN:
            self.handle_packet_in(msg)

if __name__=='__main__':
    test = Controller()
    test.setDaemon(True)
    test.start()
