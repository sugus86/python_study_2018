#-*- encoding=utf-8 -*-

import Tkinter
from Tkinter import *
from FileDialog import *
import os
import sys
reload(sys)
sys.setdefaultencoding('utf8')

root = Tk()
import tkFont
root.title('speed-cli')
root.geometry('800x400')
root.resizable(False,False)#固定窗口大小
f  = tkFont.Font(family = 'Courier New', size = 10)#字体大小

#清屏函数(这里每一个对话框都清除)
def cmd_clear():
    param_entry.delete(0, END)
    log_text.delete(1.0, END)

#命令运行函数
def cmd_run():
    _cmd  = param_entry.get()  #获取命令
    log_text.insert(END, _cmd + '\n', 'c')  #插入命令
    cmd_response = os.popen(_cmd).readlines().decode("GBK") #运行命令并获取返回内容    
    log_text.insert(END, ''.join(cmd_response), 'l')  #将返回内容写入到下面的文本框
    del cmd_response

param_entry = Entry(root, font = f, width = 60, border = 2)#创建输入框
param_entry.grid(row = 1, column = 1, sticky = W)
run_btn = Button(root,text = '运行',font = f,command = cmd_run,width = 20)#使用上面定义的函数cmd_run执行按钮
run_btn.grid(row = 1, column = 2, sticky = W)
clear_btn = Button(root,text = '清屏',  font = f,  command = cmd_clear,  width = 20)#使用上面定义的函数cmd_clear执行按钮
clear_btn.grid(row = 2, column = 2, sticky = W)
log_text = Text(root,font = f,width = 105,  border = 2,) #文本框
log_text.grid(columnspan = 3, sticky = W)
root.mainloop()
