#mysetup.py
from distutils.core import setup 
import py2exe
  
setup(console=["speedtest_cli.py"])