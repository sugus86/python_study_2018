import sqlite3

table = "ssh_to_ap_statistics" 
conn = sqlite3.connect("test.db")
cur = conn.cursor()
#sql="TRUNCATE TABLE %s" % table
sql = "delete from %s" % table
print sql
cur.execute(sql)
conn.commit()
cur.close()
