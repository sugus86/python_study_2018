import sqlite3,os

def create_sql_db():    
    conn = sqlite3.connect("test.db")
    cur = conn.cursor()
    sql_table_name = "ssh_to_ap_statistics"
    sql="create table if not exists %s (ap_name varchar(50) primary key, table_count smallint(10), \
        wifidog_count smallint(10))" % sql_table_name
    cur.execute(sql)

if __name__ == "__main__":
    filename = os.getcwd() + "\\test.db"
    
    #os.path.abspath('.')
    #os.path.isfile("xxxx.txt")
    print filename
    
    if os.path.exists(filename):
        os.remove(filename)
    create_sql_db()
