#-*- coding: utf-8 -*-
#!/usr/bin/python
import paramiko
import threading,time
import sqlite3




class Test:
    def __init__(self):
        import query_online_ap
        self.online_ap_ip = query_online_ap.mysql_query_results()
        #self.online_ap_ip = ["172.31.168.169"]

        self.username = "root"
        self.passwd = "admin123"
        self.table="ssh_to_ap_statistics" 
        self.cmd = ['cat /etc/config/general/general_config | grep APName | awk -F "\'" \'{print $4}\'',\
        '/sbin/iptables -L WiFiDog_brWAN_Global -n|grep ACCEPT|wc -l',\
        "ps|grep wifidog|wc -l"]

        print "Begin......"

    def ssh2(self,table,ip,username,passwd,cmd):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip,22,username,passwd,timeout=5)

            stdin, stdout, stderr = ssh.exec_command(cmd[0])
            stdin.write("Y")
            for s in stdout:
                ap_name = s.strip("\n")
                #print ap_name
            stdin, stdout, stderr = ssh.exec_command(cmd[1])
            for s in stdout:
                table_count = int(s)
                #print table_count
            stdin, stdout, stderr = ssh.exec_command(cmd[2])
            for s in stdout:
                wifidog_count = int(s)
                #print wifidog_count

            conn = sqlite3.connect("test.db")
            cur = conn.cursor()
            sql="insert into '%s' values('%s','%d','%d')" % (table,ap_name,table_count,wifidog_count)
            cur.execute(sql)
            conn.commit()
            cur.close()

            print '%s\t%d\t%d\n'%(ap_name,table_count,wifidog_count)
            #time.sleep(1)
            ssh.close()

        except :
            print '%s\tError\n'%(ip)

    def start(self):
        threads=[]
        for ip in self.online_ap_ip:
            self.ip=ip
            t=threading.Thread(target=self.ssh2,args=(self.table,self.ip,self.username,self.passwd,self.cmd))
            threads.append(t)
        for t in threads:
            t.start()
            time.sleep(1)
        for t in threads:
            t.join()
        print 'all thread end'


conn = sqlite3.connect("test.db")
cur = conn.cursor()
sql="delete from %s" % "ssh_to_ap_statistics"
print sql
cur.execute(sql)
conn.commit()
cur.close()

test = Test()

start_time = time.clock()
test.start()
end_time = time.clock()
print "Total run : %f s" % (end - start)
