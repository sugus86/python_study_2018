# -*- coding: utf-8 -*-
import ap_result_handler
from offline_ap_name import all_off_line_ap_name
import time

def results_to_log(tmp):    
    d1=time.strftime('%Y-%m-%d',time.localtime(time.time()))
    logfile=d1+'.log'
    b=open(logfile,'w')
    b.close() #创建空的log文件，如果之前存在则清除   
    f=open(logfile,'a+')
    f.seek(0)
    for key in tmp:
        f.writelines(tmp[key])
    f.close
    
def all_results(all_ap_name):    
    tmp={}
    log=[]
    for ap_name in all_ap_name:
        tmp[ap_name]=ap_result_handler.ap_result_handler(ap_name)
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"
    #print tmp
    for key in tmp:
        for r in tmp[key]:
            log.append(r)
            print r
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"    
    #return tmp    

def one_result(ap_name):    
    tmp={}
    tmp[ap_name]=ap_result_handler.ap_result_handler(ap_name)
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"      
    print tmp
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"      
    return tmp

if __name__== '__main__':
    test=1
    if test==0:
        all_ap=all_off_line_ap_name().all_ap        
        all_results(all_ap)
    else:
        a=one_result("LH_L6_07F_09_722_065")
        ap_result_handler.result_to_db(a)
    
