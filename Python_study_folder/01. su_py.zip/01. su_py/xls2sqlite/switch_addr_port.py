# -*- coding: utf-8 -*-

class divide_to_ip_port():
    def __init__(self,ap_name):
        self.ap_name=ap_name
        self.Dorm_name=Dorm(self.ap_name).Dorm_name
        addr_port=self.ap_addr_port()
        if self.Dorm_name!='GL_C23':
            self.ip_addr='10.137.64.'+addr_port.split('_')[0]
        elif self.Dorm_name!='GL_C23':
            self.ip_addr='10.175.132.'+addr_port.split('_')[0]
        self.port=addr_port.split('_')[1]

    def ip_port(self):
        if self.ip_addr is not str or self.port is not str:
            self.ip_addr=self.ip_addr.encode('ascii')
            self.port=self.port.encode('ascii')
        return self.ip_addr,self.port

    def ap_addr_port(self):
        import sqlite3        
        table=self.Dorm_name
        sql="select addr_port from '%s' where ap_name='%s'" % (table,self.ap_name)
        conn = sqlite3.connect("test.db")
        cur = conn.cursor()
        cur.execute(sql)
        result=cur.fetchone()
        conn.commit()
        cur.close()
        #print result
        return result[0]
   
class Dorm:
    def __init__(self,ap_name):
        self.ap_name=ap_name
        self.Dorm_name="Not_a_dorm"
        if "LH_L4" in self.ap_name:
            self.Dorm_name="L4"
        if "LH_L6" in self.ap_name:
            self.Dorm_name="L6"
        if "LH_L7" in self.ap_name:
            self.Dorm_name="L7"
        if "LH_J1" in self.ap_name:
            self.Dorm_name="J1"
        if "LH_C2" in self.ap_name:
            self.Dorm_name="C2"
        if "LH_C3" in self.ap_name:
            self.Dorm_name="C3"
        if "GL_C23" in self.ap_name:
            self.Dorm_name="GL_C23"

if __name__=='__main__':
    sw_addr,sw_port=divide_to_ip_port("LH_L6_07F_09_722_065").ip_port()
    print sw_addr,sw_port,type(sw_addr),type(sw_port)
    #print Dorm("LH_J1_11F_07_1117_119").Dorm_name
    #print "Run OK"    
