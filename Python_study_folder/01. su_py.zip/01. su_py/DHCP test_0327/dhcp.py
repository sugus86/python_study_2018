import socket,select
import logging
import struct, random

class parse_dhcp():
    message_type = 1
	hardware_type = 0x01
	hardware_length = 6
	hops = 0
	sec_elapsed = 0

    def __init__(self):
		xid = random.randint(0x10000000,0x99999999)
		self.boot_flag = 0x8000
		client_ip_addr = "0.0.0.0"
		next_server_ip_addr = "0.0.0.0"
		relay_agent_ip_addr = "0.0.0.0"
		client_mac_addr = "00:02:a5:4e:92:cf"
		client_hard_pading = "00" * 10
		server_not_given = "00" * 48
		boot_not_given = "00" * 48
		magic_cookie = "63:82:53:63"
		options = []

    def pack(self):
        packed = []
        packed.append(struct.pack("!B", self.version))
        packed.append(struct.pack("!B", self.type))
        packed.append(struct.pack("!H", 0))
        packed.append(struct.pack("!L", self.xid))
        length = sum([len(x) for x in packed])
        packed[2] = struct.pack("!H", length)
        return ''.join(packed)

    @staticmethod
    def unpack(reader):
        obj = hello()
        _version = reader.read("!B")[0]
        assert(_version == 4)
        _type = reader.read("!B")[0]
        assert(_type == 0)
        _length = reader.read("!H")[0]
        orig_reader = reader
        reader = orig_reader.slice(_length - (2 + 2))
        obj.xid = reader.read("!L")[0]
        obj.elements = loxi.generic_util.unpack_list(reader, common.hello_elem.unpack)
        return obj

def parse_mac(mac_str):
    return map(lambda val: int(val, 16), mac_str.split(":"))

def parse_ip(ip_str):
    array = map(lambda val: int(val), ip_str.split("."))
    val = 0
    for a in array:
        val <<= 8
        val += a
    return val