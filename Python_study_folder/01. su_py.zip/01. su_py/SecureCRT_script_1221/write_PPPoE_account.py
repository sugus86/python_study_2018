# $language = "python"
# $interface = "1.0"

def main():
	crt.Screen.Synchronous = True
	#promptString = "#"
	#account=get_account()
	check_version()
	#crt.Screen.Send("echo "+account[0]+account[1]+account[2]+"\r")

	crt.Screen.Synchronous = False
	
def check_version():
	crt.Screen.WaitForString('#',3)	
	crt.Screen.Send ("cat /etc/config/general/sysinfo|grep FirmwareVersion\r")
	crt.Screen.WaitForString('#',3)	
	
def get_MAC():
	crt.Screen.Send("ifconfig brWAN |grep HWaddr |awk '{print $5}'"+"\r")
	crt.Screen.WaitForString('#')
	screenrow = crt.Screen.CurrentRow - 1
	#crt.Sleep(100)
	result = crt.Screen.Get(screenrow, 1, screenrow, 17)
	crt.Screen.Send("echo "+result+"\r")
	return result

def get_account():
	mac_addr = get_MAC()
	#crt.Screen.Send(mac_addr+"\r")
	#crt.Screen.Send(("echo %d\r") %len(mac_addr))
	f = open("test.txt",'r')
	lines  = f.readlines()	
	for line in lines:
		if not line[:-1].strip():
			continue
		#crt.Screen.Send(("echo %s"+"\r") %line)
		#crt.Sleep(200)
		line_split = line.split()
		if mac_addr == line_split[0]:
			#crt.Screen.Send(("echo find mac:%s and its account is: %s_%s"+"\r") %(line_split[0],line_split[1],line_split[2]))
			write_account(line_split[1],line_split[2])
			return line_split

def write_account(account_name,account_pass):
	crt.Screen.Send ("uci -c /etc/config/general/ set wan.WANIPConnection.AddressingType=PPPoE\r")
	crt.Screen.Send ("uci -c /etc/config/general/ set wan.WANIPConnection.PPPoEUserName="+account_name+"\r")
	crt.Screen.Send ("uci -c /etc/config/general/ set wan.WANIPConnection.PPPoEPassword="+account_name+"\r")
	crt.Screen.Send ("uci -c /etc/config/general/ commit wan"+"\r")
	crt.Screen.Send ("cat /etc/config/general/wan\r")	

main()