# $language = "python"
# $interface = "1.0"

def main():
	crt.Screen.Synchronous = True

	promptString = "#"
	
	crt.Screen.Send("ifconfig brWAN |grep HWaddr |awk '{print $5}'"+"\r")
	screenrow = crt.Screen.CurrentRow - 1
	crt.Screen.WaitForString(promptString)
	crt.Sleep(100)
	mac_addr = crt.Screen.Get(screenrow, 1, screenrow, 40)
	crt.Screen.Send(("%s"+"\r") %mac_addr)

	crt.Screen.Synchronous = False
	

main()