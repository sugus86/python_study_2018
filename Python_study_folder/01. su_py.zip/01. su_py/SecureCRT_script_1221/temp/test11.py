def main():
	crt.Screen.Synchronous = True
	if 1:crt.Screen.Send("date\r")
	crt.Screen.Synchronous = False
main()