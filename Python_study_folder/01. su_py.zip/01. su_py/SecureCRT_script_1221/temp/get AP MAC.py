# $language = "python"
# $interface = "1.0"

def main():
	crt.Screen.Synchronous = True
	#crt.Screen.Send("date\r")
	promptString = "#"
	crt.Screen.WaitForString(promptString)
	mac_addr = get_MAC()
	crt.Sleep(1000)
	crt.Screen.Send(("echo "+mac_addr+"\r")	

	#f = open("test.txt",'r')
	#lines  = f.readlines()	
	#for lines in line:
		#crt.Screen.Send(("echo %s"+"\r") %line)
	
	crt.Screen.Synchronous = False
	
def get_MAC():
	crt.Screen.Send("ifconfig brWAN |grep HWaddr |awk '{print $5}'"+"\r")
	screenrow = crt.Screen.CurrentRow - 1
	result = crt.Screen.Get(screenrow, 1, screenrow, 17)
	crt.Screen.Send("echo "+result+"\r")		
	return result
	
main()