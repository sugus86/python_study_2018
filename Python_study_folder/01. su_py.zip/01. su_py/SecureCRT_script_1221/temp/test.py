# $language = "python"
# $interface = "1.0"

def main():
	'''
	crt.Screen.Synchronous = True
	crt.Screen.Send("date\r")
	promptString = "#"
	crt.Screen.WaitForString(promptString)
	screenrow = crt.Screen.CurrentRow - 1
	result = crt.Screen.Get(screenrow, 1, screenrow, 40)
	crt.Dialog.MessageBox(result)
	crt.Screen.Synchronous = False
	'''

	#crt.Screen.Synchronous = True	
	crt.Screen.Send("uci -c /etc/config/general/ get capwap.controller.DefaultIPAddress"+"\r")
	screenrow = crt.Screen.CurrentRow - 1
	crt.Sleep(100)
	result = crt.Screen.Get(screenrow, 1, screenrow, 40)
	#crt.Dialog.MessageBox(result)
	#crt.Screen.Send(result+"\r")	

	if (result.strip() == "172.19.96.51"):
		#crt.Dialog.MessageBox(result)
		crt.Screen.Send("uci -c /etc/config/general/ set capwap.controller.DefaultIPAddress='10.134.42.100'"+"\r")
		crt.Screen.Send("uci -c /etc/config/general/ commit capwap"+"\r")
	elif (result.strip() == "10.134.42.100"):
		crt.Screen.Send("uci -c /etc/config/general/ set capwap.controller.DefaultIPAddress='172.19.96.51'"+"\r")
		crt.Screen.Send("uci -c /etc/config/general/ commit capwap"+"\r")
		
	crt.Screen.Send("uci -c /etc/config/general/ get capwap.controller.DefaultIPAddress"+"\r")
	#crt.Screen.Synchronous = False

main()