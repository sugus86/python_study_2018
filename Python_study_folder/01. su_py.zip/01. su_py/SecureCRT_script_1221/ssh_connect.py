# $language = "python"
# $interface = "1.0"

def main():
	obj = crt.GetScriptTab()
	crt.Screen.Synchronous = True

	errcode = 0
	#errcode = 1
	for i in range(1,10):
		try:
			crt.Sleep(500)
			#crt.Session.Connect("/SSH2 /PASSWORD admin123 root@192.168.1."+str(i), True)
			crt.Session.Connect("/SSH2 /P 22 /L root /PASSWORD admin123 192.168.1."+str(i))
		except ScriptError:
			errcode = crt.GetLastError()
		if errcode != 0:
			pass
		 	#crt.Dialog.MessageBox("Connection Failed")
		else:
			#crt.Dialog.MessageBox("Connection Successful")
			#obj = crt.GetActiveTab()
			crt.Sleep(500)
			crt.Screen.Send("\r")
			crt.Sleep(1000)
			obj.Screen.WaitForString("#",3)			
			obj.Screen.Send("cat /etc/config/general/sysinfo|grep Firmware \n")
			obj.Screen.WaitForString("#",3)
			obj.Screen.Send("exit\n")
			#obj.Session.Disconnect()	

	crt.Screen.Synchronous = False

main()