



testfile = "10.137.64.84_tmp.txt"
f = open(testfile,'r+')
f_tmp = open('10.137.64.84.txt','w+')

for line in f:
    if "c0ff-d4" in line:
        if "[16D" in line:
            line = line [26:]
        if "GigabitEthernet" in line:
            continue
        f_tmp.write(line)

f.close()
f_tmp.close()



'''
fh = open('aaa.py')
fh_tmp = open('bbb.py','w+')
#for line in fh.readlines():
for line in fh:
    if line:
        #fh_tmp.write(line)
        #fh_tmp.write("user_add")
        fh_tmp.write(line[3:])

fh.close()
fh_tmp.close()


qfile = open('wq.txt','w').writelines([l for l \
in open('ww.txt','r').readlines() if l[:-1].strip()

'''
