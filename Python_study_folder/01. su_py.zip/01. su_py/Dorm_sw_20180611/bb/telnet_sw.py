#-*- coding: utf8 -*-

import telnetlib, time, os

sw_addr_list_J2 = ["10.137.64.82","10.137.64.83","10.137.64.84","10.137.64.85","10.137.64.86",\
                "10.137.64.87","10.137.64.88","10.137.64.89","10.137.64.90"]
sw_addr_list_J3 = []
sw_addr_list_J8 = []
sw_addr_list_J9 = []
sw_addr_list_J10 = []
sw_addr_list_J11 = []
sw_addr_list_J12 = []
#sw_addr_list = ["10.137.64.82"]

sw_addr_list = sw_addr_list_J2 + sw_addr_list_J3 + sw_addr_list_J8 + sw_addr_list_J9 + sw_addr_list_J10\
 + sw_addr_list_J11 + sw_addr_list_J12

def do_telnet(sw_addr):
   username="cisco"
   password="cisco"
   finish='>'
   tn = telnetlib.Telnet(sw_addr, port=23, timeout=10)  
   tn.set_debuglevel(2)     
   #tn.read_until('user name:')  
   #tn.write(username + '\n')   
   tn.read_until('Password:')  
   tn.write(password + '\n')    
   tn.read_until('>')  
   tn.write("super" + '\n')
   tn.read_until('Password:')  
   tn.write(password + '\n')    
   tn.read_until(finish) 
   command="display mac-address"
   tn.write(command + '\n')
   i = 1
   mac_address_results = ""
   cr = "\n"
   while i < 30:
      read_until = tn.read_until("---- More ----",2)      
      if read_until:
         mac_address_results += cr + read_until
         tn.write(' ')
      else:
         tn.read_until(finish,2)
         break
      i += 1
   #tn.read_until(finish)
   time.sleep(5)
   tn.close()
   
   return mac_address_results

def mac2text():
   for sw_addr in sw_addr_list:
      mac_address_results = do_telnet(sw_addr)
      filename = sw_addr + "_tmp.txt"
      f_tmp = open(filename,'w+')
      f_tmp.writelines(mac_address_results)
      f_tmp.close()

      f_final = open(sw_addr + ".txt", 'w+')
      with open(filename,'r+') as f:
         lines = f.readlines()
         for line in lines:
            if "c0ff-d4" in line:
               if "[16D" in line:
                  line = line [26:]
               if "GigabitEthernet" in line:
                  continue
               f_final.writeline(line)      
      f_final.close()
      os.remove(os.getcwd() + "\\" + filename)

if __name__ == '__main__':
   mac2text()  
