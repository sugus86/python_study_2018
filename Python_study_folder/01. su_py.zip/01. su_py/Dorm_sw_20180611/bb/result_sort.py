import os

def mac2mac(mac):	
	assert len(mac) == 14 
	mac_split = mac.split("-")
	mac_mac = ""
	for i in mac_split:
		assert len(i) >=2
		#print i
		for j in range(len(i)/2):
			mac_mac += i[j*2:j*2+2] + ":"
	return mac_mac[:-1]

def parse_text(text):
	text_content = text.split(" ")	
	text_content = [x for x in text_content if x != ""]
	#print text_content 
	for i in text_content:
		#print i
		pass
	return text_content

def test_text(text_file):
	mac_port = {}
	lines = open(text_file, 'r+').readlines()
	for i in lines:
		j = parse_text(i)
		mac_port[mac2mac(j[0])] = j[3]
	return mac_port

if __name__ == "__main__":
	#print mac2mac("1234-abcd-6789")
	t_file = os.getcwd() + "\\" + "10.137.64.84.txt"
	print test_text(t_file)




