

file = "10.137.64.82_tmp.txt"
f = open(file,'r+')
f_tmp = open('10.137.64.82.txt','w+')
for line in f:
    if "c0ff-d4" in line:
        if "128" in line:
            f_tmp.write(line)

f.close()
f_tmp.close()



'''
fh = open('aaa.py')
fh_tmp = open('bbb.py','w+')
#for line in fh.readlines():
for line in fh:
    if line:
        #fh_tmp.write(line)
        #fh_tmp.write("user_add")
        fh_tmp.write(line[3:])

fh.close()
fh_tmp.close()

'''
