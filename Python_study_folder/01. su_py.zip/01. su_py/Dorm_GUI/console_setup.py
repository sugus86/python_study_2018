#mysetup.py
from distutils.core import setup 
import py2exe
  
setup(console=["Dorm_offline_ap.py"])
