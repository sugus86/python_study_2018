# -*- coding: utf-8 -*-
Dorm_List = ["_C2_","_C3_","_C23_","_L4_","_L6_" ,"_L7_","_J1_"]

class all_off_line_ap_name():    
    def __init__(self):
        self.all_ap=self.mysql_query_results()
        
    def mysql_query_results(self):
        import MySQLdb
        conn=MySQLdb.connect(host="10.134.42.160",user="r_sqawlc",passwd="r_lhsqapw",db="wlcdb",charset="utf8")
        cursor = conn.cursor()
        ap_mac_tmp=[]
        n = cursor.execute("SELECT ap_mac FROM wlcdb.table_ap_runtime_config where status ='0'")
        for row in cursor.fetchall():
            for r in row:
                ap_mac_tmp.append(r)   
        ap_name_tmp=[]
        for param in ap_mac_tmp:
            m = cursor.execute("SELECT ap_name FROM wlcdb.table_ap_config where ap_mac = %s",param)
            for row in cursor.fetchall():
                for r in row:
                    ap_name_tmp.append(r)

        #print ap_name_tmp       
        all_ap_tmp = []
        for r in ap_name_tmp:
            if r is None:
                continue
            elif len(r.split('_')) <6:
                continue
            elif "_C2_" not in r and "_C3_" not in r and "_L4_" not in r and "_L6_" not in r\
            and "_L7_" not in r and "_J1_" not in r and "_C23_"not in r:
                continue          
            else:
                all_ap_tmp.append(r)    

        return all_ap_tmp
        
if __name__=='__main__':
    print "This information only for debug!\n"
    print "-+-+-+-+ All off line AP on AC: 10.134.42.100  -+-+-+-+-+"
    L4_offline_ap = ["L4_offline_ap"]
    L6_offline_ap = ["L6_offline_ap"] 
    L7_offline_ap = ["L7_offline_ap"] 
    C2_offline_ap = ["C2_offline_ap"] 
    C3_offline_ap = ["C3_offline_ap"] 
    C23_offline_ap = ["C23_offline_ap"] 
    J1_offline_ap = ["J1_offline_ap"]

    for r in all_off_line_ap_name().all_ap:
      if "_L4_" in r:
        L4_offline_ap.append(r)
      elif "_L6_" in r:
        L6_offline_ap.append(r)
      elif "_L7_" in r:
        L7_offline_ap.append(r)
      elif "_C2_" in r:
        C2_offline_ap.append(r)        
      elif "_C3_" in r:
        C3_offline_ap.append(r) 
      elif "_C23_" in r:
        C23_offline_ap.append(r)    
      elif "_J1_" in r:
        J1_offline_ap.append(r)

    all_Dorm_List = [L4_offline_ap,L6_offline_ap,L7_offline_ap,C2_offline_ap,C3_offline_ap,C23_offline_ap,J1_offline_ap]

    for r in all_Dorm_List:
      if len(r) == 1:
        continue
      else:
        print "\n",r[0],"-+-+"*11
        r=r[1:]
        r.sort()
        for i in r:
          print i
    print "-+"*30
