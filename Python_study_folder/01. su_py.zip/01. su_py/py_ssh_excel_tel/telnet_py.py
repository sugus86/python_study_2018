#-*- coding: utf8 -*-
def do_telnet(Host, username, password, finish, commands):
   import telnetlib   
   tn = telnetlib.Telnet(Host, port=23, timeout=10)  
   tn.set_debuglevel(2)     
   tn.read_until('user name:')  
   tn.write(username + '\n')   
   tn.read_until('password:')  
   tn.write(password + '\n')    
   tn.read_until('>')  
   tn.write("en" + '\n')
   tn.read_until('password:')  
   tn.write("lhadsl" + '\n')    
   tn.read_until(finish)  
   for command in commands:  
       tn.write('%s\n' % command)     
   tn.read_until(finish)
   tn.close() # tn.write('exit\n')
	   
if __name__=='__main__':   
   Host = '10.137.64.20'   
   username = 'lhsqa'
   password = 'lhsqa'  
   finish = '#'   
   commands = ['show ip route']  
   do_telnet(Host, username, password, finish, commands)  

