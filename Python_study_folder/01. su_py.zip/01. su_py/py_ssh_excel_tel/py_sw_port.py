#-*- coding: utf8 -*-
def do_telnet(Host,commands):
   import telnetlib   
   tn = telnetlib.Telnet(Host, port=23, timeout=10)  
   tn.set_debuglevel(2)     
   tn.read_until('user name:')  
   tn.write("lhsqa" + '\n')   
   tn.read_until('password:')  
   tn.write("lhsqa" + '\n')    
   tn.read_until('>')  
   tn.write("en" + '\n')
   tn.read_until('password:')  
   tn.write("lhadsl" + '\n')    
     
   for command in commands:
       tn.read_until("#")   
       tn.write('%s\n' % command)
   #tn.read_until("#")
   tn.close()
   
if __name__ == '__main__':
   import xlrd
   data=xlrd.open_workbook("test.xlsx")
   table=data.sheets()[0]
   finish='#' 
   for i in range(table.nrows):
      apname=table.cell(i,0).value
      apsw=int(table.cell(i,1).value)
      apswport=int(table.cell(i,2).value)
      if "GL" in apname:
	     Host="10.175.132."+str(apsw)
      else:
	     Host="10.137.64."+str(apsw)
      commands=("config t","int gi 0/"+str(apswport),"no poe enable","poe enable","end","exit") 
      do_telnet(Host,commands)
      print apname+" has reboot"
