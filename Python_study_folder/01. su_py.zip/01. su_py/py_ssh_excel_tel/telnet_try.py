#-*- coding: utf8 -*-
def do_telnet(Host, username, password, finish,sw_port):
   import telnetlib   
   tn = telnetlib.Telnet(Host, port=23, timeout=10)  
   tn.set_debuglevel(2)     
   tn.read_until('user name:')  
   tn.write(username + '\n')   
   tn.read_until('password:')  
   tn.write(password + '\n')    
   tn.read_until('>')  
   tn.write("en" + '\n')
   tn.read_until('password:')  
   tn.write("lhadsl" + '\n')    
   tn.read_until(finish)
   tn.write("show poe interface 
   tn.read_until(finish)
   tn.close()
	   
if __name__=='__main__':   
   import xlrd
   data=xlrd.open_workbook("AP_sw_port.xlsx")
   table=data.sheets()[0]
   finish='#' 
   for i in range(1,table.nrows):
      apname=table.cell(i,0).value
      sw_addr=int(table.cell(i,1).value)
      sw_port=int(table.cell(i,2).value)
      do_telnet(sw_addr, "lhsqa", "lhsqa", sw_port)
