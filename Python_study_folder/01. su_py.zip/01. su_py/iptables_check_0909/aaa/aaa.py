import threading

class Demo:
    def __init__(self,thread_num=5):
        self.thread_num=thread_num
    def productor(self,i):
        print "thread-%d start\n" %i
    def start(self):
        threads=[]
        for x in xrange(self.thread_num):
            t=threading.Thread(target=self.productor,args=(x,))
            threads.append(t)
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        print 'all thread end'


demo=Demo()
demo.start()
