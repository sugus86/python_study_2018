#-*- coding: utf-8 -*-
#!/usr/bin/python
import paramiko
import threading,time
import sqlite3


def ssh2(cur,conn,table,ip,username,passwd,cmd):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip,22,username,passwd,timeout=5)

        stdin, stdout, stderr = ssh.exec_command(cmd[0])
        stdin.write("Y")
        for s in stdout:
            ap_name = s
        stdin, stdout, stderr = ssh.exec_command(cmd[1])
        for s in stdout:
            table_count = s
        stdin, stdout, stderr = ssh.exec_command(cmd[2])
        for s in stdout:
            wifidog_count = s        

        sql="insert into '%s' values('%s','%s','%s')" % (table,ap_name,table_count,wifidog_count)
        cur.execute(sql)
        conn.commit()

        print '%s\t%d\t%d\n'%(ap_name,table_count,wifidog_count)
        time.sleep(2)
        ssh.close()

    except :
        print '%s\tError\n'%(ip)

if __name__=='__main__':
    import query_online_ap

    #online_ap_ip = query_online_ap.mysql_query_results()
    online_ap_ip = ["172.31.168.169"]

    cmd = ['cat /etc/config/general/general_config | grep APName | awk -F "\'" \'{print $4}\'',\
           '/sbin/iptables -L WiFiDog_brWAN_Global -n|grep ACCEPT|wc -l',\
           "ps|grep wifidog|wc -l"]
    
    username = "root"
    passwd = "admin123"
    print "Begin......"

    conn = sqlite3.connect("test.db")
    cur = conn.cursor()
    table="ssh_to_ap_statistics"

    for ip in online_ap_ip:
        a=threading.Thread(target=ssh2,args=(cur,conn,table,ip,username,passwd,cmd))
        a.start()
        #a.join()

    cur.close()
    #print "\n......successfully!"
