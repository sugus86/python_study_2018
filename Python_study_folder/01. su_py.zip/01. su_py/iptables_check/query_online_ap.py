def mysql_query_results():
    import MySQLdb
    conn=MySQLdb.connect(host="10.134.42.160",user="r_sqawlc",passwd="r_lhsqapw",db="wlcdb",charset="utf8")
    cursor = conn.cursor()
    ap_ip_tmp=[]
    n = cursor.execute("SELECT ip FROM wlcdb.table_ap_runtime_config where status ='1'")
    for row in cursor.fetchall():
        for r in row:
            ap_ip_tmp.append(r)

    return ap_ip_tmp


if __name__ == '__main__':
    online_ap_ip = mysql_query_results()
    for i in online_ap_ip:
        print i

    print "\nTotal %d AP is online." %len(online_ap_ip)

    
    '''
    def ssh_ip(ip):
    '''
