

import paramiko

#ssh_server = raw_input("please input the ssh server ip:\n")
ssh_server = "10.135.66.6"
client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect(ssh_server, username='root', password='admin123')
stdin, stdout, stderr = client.exec_command('/sbin/iptables -L -n')
for line in stdout:
	print '... ' + line.strip('\n')
client.close()
