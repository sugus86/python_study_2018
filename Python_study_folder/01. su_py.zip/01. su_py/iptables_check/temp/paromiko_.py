import paramiko

t=paramiko.Transport(("10.135.74.10",22))
t.connect(username="root",password="admin123")
chan=t.open_session()
chan.settimeout(5)
chan.get_pty()
chan.invoke_shell()

chan.send('ls /')
print chan.recv(65535)


str=chan.recv(recv_buffer)
while not str.endswith('#'):
    str=chan.recv(recv_buffer)
