#-*- coding: utf-8 -*-
#!/usr/bin/python
import paramiko
import threading
def ssh2(ip,username,passwd,cmd):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip,22,username,passwd,timeout=5)
        stdin, stdout, stderr = ssh.exec_command(cmd[0])
        stdin.write("Y")
        for s in stdout:
            ap_name = s
        stdin, stdout, stderr = ssh.exec_command(cmd[1])
        for s in stdout:
            table_count = s
        results_to_db(ap_name,table_count)
        print '%s\t%d\n'%(ap_name,table_count)
        ssh.close()
    except :
        print '%s\tError\n'%(ip)

def results_to_db(p1,p2):
    import sqlite3
    conn = sqlite3.connect("test.db")
    cur = conn.cursor()
    table="ap_name_table_count"
    #sql="insert into '%s' values('%s','%s')" % (table,ap_name,table_count)
    sql="insert into '%s' values('%s','%s')" % (table,p1,p2)
    cur.execute(sql)
    conn.commit()
    cur.close()

if __name__=='__main__':
    import query_online_ap
    online_ap_ip = query_online_ap.mysql_query_results()
    cmd = ['cat /etc/config/general/general_config | grep APName | awk -F "\'" \'{print $4}\'',\
           '/sbin/iptables -L WiFiDog_brWAN_Global -n|grep ACCEPT|wc -l']
    
    username = "root"
    passwd = "admin123"
    threads = [] 
    print "Begin......"
    #flag = 0
    for ip in online_ap_ip:
        #if flag > 2:break
        a=threading.Thread(target=ssh2,args=(ip,username,passwd,cmd))
        a.start()
        #flag +=1
        a.join()
    print "\n......successfully!"
