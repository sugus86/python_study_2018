# -*- coding: utf-8 -*-
import ap_sw
import telnet_sw

def ap_result_handler(ap_name):
    import time
    lines=[]
    poe_results,int_results=telnet_sw.do_telnet(ap_name)    
    d2=time.strftime('%H:%M:%S',time.localtime(time.time()))
    lines.append(d2+'\n')
    lines.append("######################   " + ap_name +  "   #####################\n")
    if poe_results=="poe_error" or int_results=="port_error":
        return "result_error"
    for t in poe_results:
        lines.append(t.split(':')[6].split()[0]+"/"+t.split(':')[8].split()[0]+"\n")
    lines.append(int_results.split('\n')[1])
    lines.append("#########################################################################"+"\n\n")
    return lines

if __name__== '__main__':
    print "These information is only for debug!"
    ap_name="LH_C2_1F_12_149_012"
    result=ap_result_handler(ap_name)
    if result=="result_error":
        print result
    else:
    #print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+"
        for r in result:
            print r
    #print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+"
