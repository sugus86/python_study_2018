#import sys
#sys.path.append(r'H:\py_db')
from offline_ap_name import ap_name_is
print ap_name_is()

