# -*- coding: utf-8 -*-
#mysqldb
import MySQLdb
conn=MySQLdb.connect(host="10.134.42.160",user="r_sqawlc",passwd="r_lhsqapw",db="wlcdb",charset="utf8")
cursor = conn.cursor()
ap_mac_tmp=[]
n = cursor.execute("SELECT ap_mac FROM wlcdb.table_ap_runtime_config where status ='0'")
for row in cursor.fetchall():
    for r in row:
        ap_mac_tmp.append(r)   
ap_name_tmp=[]
for param in ap_mac_tmp:
    m = cursor.execute("SELECT ap_name FROM wlcdb.table_ap_config where ap_mac = %s",param)
    for row in cursor.fetchall():
        for r in row:
            ap_name_tmp.append(r)
all_ap_name=[]
for r in ap_name_tmp:
    if len(r.split('_'))>5:
        all_ap_name.append(r)
def ap_name_is():
    return all_ap_name

if __name__=='__main__':
    print "This information only for debug!\n"
    print "-+-+-+-+ All off line AP on AC: 10.134.42.100  -+-+-+-+-+"
    for r in all_ap_name:
        print r
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+"
