import xlrd
from ap_sw import ap_sw 
def xlrd_handler():
    data=xlrd.open_workbook("AP_sw_port_daily.xlsx")
    ap_name="LH_C3_05F_17_563_087"
    Dorm_name=ap_sw(ap_name).is_Dorm()    
    table=data.sheet_by_name(Dorm_name)
    for i in range(1,table.nrows):            
            if ap_name==table.cell(i,0).value:
                print ap_name
                if str(table.cell(i,1).value)=="empty:''" or str(table.cell(i,1).value)=="empty:''":
                    print "addr_error or port_error"
                else:
                    sw_addr=table.cell(i,1).value
                    sw_port=table.cell(i,2).value
                    print sw_addr,sw_port
            else:
                if i==table.nrows-1:
                    print ap_name+" Not Found"

xlrd_handler()
