# -*- coding: utf-8 -*-
import ap_sw
import telnet_sw
if __name__== '__main__':
    from offline_ap_name import ap_name_is
    import time
    all_ap=ap_name_is()
    print "-+-+-+-+-+-+-+ Today off line AP are below: -+-+-+-+-+-+-+-+-+\n"
    for ap in all_ap:
        print ap
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"
    d1=time.strftime('%Y-%m-%d',time.localtime(time.time()))
    logfile=d1+'.log'
    open(logfile,'w')
    print logfile+" is create or clear at "+d1+"\n"
    with open(logfile,'a+') as f:
        f.seek(0)        
        for ap in all_ap:
            lines=[]
            poe_results,int_results=telnet_sw.do_telnet(ap)            
            d2=time.strftime('%H:%M:%S',time.localtime(time.time()))
            lines.append(d2+'\n')
            lines.append("#############################   " + ap +  "   ##########################\n")
            for t in poe_results:
                lines.append(t.split(':')[6].split()[0]+"/"+t.split(':')[8].split()[0]+"\n")
            lines.append(int_results.split('\n')[1])
            lines.append( "#################################################################################"+"\n\n")
            f.writelines(lines) 	 



    
