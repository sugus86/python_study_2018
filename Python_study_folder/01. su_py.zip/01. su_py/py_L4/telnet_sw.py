#-*- coding: utf8 -*-
import ap_sw
def do_telnet(ap_name):
   import telnetlib
   sw_addr,sw_port=ap_sw.ap_sw(ap_name).xlrd_handler()
   if sw_addr=="addr_error" or sw_port=="port_error":	  
      return "poe_error" ,"int_error"
   username="lhsqa"  
   password="lhsqa"
   finish='#'
   sw_port=str(int(sw_port))
   tn = telnetlib.Telnet(sw_addr, port=23, timeout=10)  
   tn.set_debuglevel(2)     
   tn.read_until('user name:')  
   tn.write(username + '\n')   
   tn.read_until('password:')  
   tn.write(password + '\n')    
   tn.read_until('>')  
   tn.write("en" + '\n')
   tn.read_until('password:')  
   tn.write("lhadsl" + '\n')    
   tn.read_until(finish)
   command="show poe interface gi 0/" + sw_port
   tn.write(command + '\n')
   temp1=tn.read_until(finish)
   tn.write(command + '\n')
   temp2=tn.read_until(finish)
   tn.write(command + '\n')
   temp3=tn.read_until(finish)
   tn.write(command + '\n')
   temp4=tn.read_until(finish)
   tn.write(command + '\n')
   temp5=tn.read_until(finish)
   poe_results=(temp1,temp2,temp3,temp4,temp5)
   command2="show interface gi 0/" + sw_port
   tn.write(command2 + '\n')
   int_results=tn.read_until(finish)
   tn.close()
   return poe_results,int_results

if __name__ =='__main__':
   print "These information is only for debug!"
   ap_name="LH_L6_07F_09_722_065"
   poe_results,int_results=do_telnet(ap_name)
   if poe_results=="poe_error" or int_results=="int_error":
      print "result has error"
   else:
      print "\n"
      print "-+-+-+-+-+-+-+-+-  "+ap_name+"  -+-+-+-+-+-+-+-+-+-+-+"
      for t in poe_results:
         print t.split(':')[6].split()[0]+"/"+t.split(':')[8].split()[0]+"\n"
      print int_results.split('\n')[1]
      print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+"
              
