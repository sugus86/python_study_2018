# -*- coding: utf-8 -*-
import xlrd

class ap_sw():
    def __init__(self,ap_name):
        self.sw_addr=""
        self.sw_port=""
        self.ap_name=ap_name
        
    def is_Dorm(self):
        if "LH_L4" in self.ap_name:
            return "L4"
        if "LH_L6" in self.ap_name:
            return "L6"
        if "LH_L7" in self.ap_name:
            return "L7"
        if "LH_J1" in self.ap_name:
            return "J1"
        if "LH_C2" in self.ap_name:
            return "C2"
        if "LH_C3" in self.ap_name:
            return "C3"
        if "GL_C23" in self.ap_name:
            return "GL_C23"

    def xlrd_handler(self):
        data=xlrd.open_workbook("AP_sw_port_daily.xlsx")
        Dorm_name=self.is_Dorm()        
        table=data.sheet_by_name(Dorm_name)
        for i in range(1,table.nrows):
            if self.ap_name==table.cell(i,0).value:
                print self.ap_name
                if str(table.cell(i,1).value)=="empty:''" or str(table.cell(i,1).value)=="empty:''":
                    return "addr_error","port_error"
                else:
                    self.sw_addr=table.cell(i,1).value
                    self.sw_port=table.cell(i,2).value         
                    return self.sw_addr,self.sw_port                                    
            elif i==table.nrows-1:
                print self.ap_name+" Not Found"
                return "addr_error","port_error"
        
if __name__ =='__main__':
    print "This informantion only for debug!\n"
    print "I return the switch address and port of the AP."    
    test=1
    if test==1:
        ap_name="LH_C3_5F_17_563_087"
        sw_addr,sw_port=ap_sw(ap_name).xlrd_handler()
        print sw_addr,sw_port
