# -*- coding: utf-8 -*-
import ap_sw, telnet_sw, ap_result_handler
from offline_ap_name import ap_name_is
import time

def results_to_log(tmp):    
    d1=time.strftime('%Y-%m-%d',time.localtime(time.time()))
    logfile=d1+'.log'
    b=open(logfile,'w')
    b.close() #创建空的log文件，如果之前存在则清除   
    f=open(logfile,'a+')
    f.seek(0)
    for key in tmp:
        f.writelines(tmp[key])
    f.close
    
def all_results(all_ap_name):    
    tmp={}
    for ap_name in all_ap_name:
        tmp[ap_name]=ap_result_handler.ap_result_handler(ap_name)
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"
    print tmp
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"    
    #return tmp

def one_result(ap_name):    
    tmp={}
    tmp[ap_name]=ap_result_handler.ap_result_handler(ap_name)
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"      
    print tmp
    print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n"      
    #return tmp

if __name__== '__main__':
    test=0
    if test==0:
        all_ap=ap_name_is()
        all_results(all_ap)
    else:
        one_result("LH_L6_07F_09_722_065")
    
